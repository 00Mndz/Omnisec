<?php
require 'verifica.php';

if(isset($_SESSION['iduser']) && !empty($_SESSION['iduser'])):
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA Compatible" content="ie-edge">
    <title>DashboardDocument</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/js/dataTables.bootstrap5.js">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.8/js/dataTables.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    </head>
<body class="container mt-4 bg-dark">
<nav class="navbar navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="onisesh.png" alt="" style="width:80px;height:80px;"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?pg=vendas">Vendas</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php?pg=membros">Membros</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Outros
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="index.php?pg=acoes">Ações</a></li>
            <li><a class="dropdown-item" href="index.php?pg=votacoes">Votações</a></li>
            <li><a class="dropdown-item" href="index.php?pg=quemsomos">Quem somos</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <div class="form inline my 2 my-lg-0">
      <label class="mr-"><?php echo '<font color="white"><p class="lead">'."$emailuser "?></label>
      <a href="logout.php"><img src="sair.png" alt="sair" style="width:42px;height:42px;"></a>
      
        
  </div>
</nav>
<main>
  <div class="container-fluid">
    <?php
    $pg = "";
    if(isset($_GET['pg']) && !empty($_GET['pg'])){
      $pg = addslashes($_GET['pg']);
    }

    switch($pg){
      case 'acoes': require 'acoes.php'; break;
      case 'votacoes': require 'votacoes.php'; break;
      case 'vendas': require 'vendas.php'; break;
      case 'membros': require 'membros.php'; break;
      case 'quemsomos': require 'quemsomos.php'; break;
      default: require 'home.php';

    }

    ?>

  </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>

<?php else: header("Location: login.php"); endif; ?>