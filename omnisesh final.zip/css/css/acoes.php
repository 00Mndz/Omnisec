<h5 class="mt-3">
<div class="container text-center">
  <div class="row">
    <div class="col">
      Ação
    </div>
    <div class="col">
      Resultado
    </div>
    <div class="col">
      Lucro
    </div>
  </div>
</div>
</h5>
<h5 class="mt-3">
<div class="container text-center">
  <div class="row">
    <div class="col">
      Niobio
    </div>
    <div class="col">
      Vitoria
    </div>
    <div class="col">
      402.654,00
    </div>
  </div>
</div>
</h5>