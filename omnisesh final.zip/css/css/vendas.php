<h5 class="mt-3">
<div class="container text-center">
  <div class="row">
    <div class="col">
      Produto
    </div>
    <div class="col">
      Quantidade
    </div>
    <div class="col">
      Lucro
    </div>
  </div>
</div>
</h5>
<h5 class="mt-3">
<div class="container text-center">
  <div class="row">
    <div class="col">
      Chave Mestra
    </div>
    <div class="col">
      8
    </div>
    <div class="col">
      12.000,00
    </div>
  </div>
</div>
</h5>