<h5 class="mt-3">Votações</h5>
<HTML>
<HEAD>
<TITLE>votação</TITLE>
</HEAD>
<BODY>
<FOUNT SIZE="3">Escolha sua próxima ação?</FOUNT><BR>
<FORM NAME="votação" ACTION="votacao.php" METHOD="get">
<INPUT TYPE="radio" NAME="escolha" VALUE="1">Nióbio<BR>
<INPUT TYPE="radio" NAME="escolha" VALUE="2">Teatro<BR>
<INPUT TYPE="radio" NAME="escolha" VALUE="3">Açogue<BR>
<button type="submit">VOTAR</button>
</FORM>
</BODY>
</HTML>
<?

